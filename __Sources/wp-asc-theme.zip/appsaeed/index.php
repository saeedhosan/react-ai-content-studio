<?php

get_header()?>
<div id="homepage"></div>

<h1>Nothing to see here this page locate to another</h1>
<?php get_footer()?>