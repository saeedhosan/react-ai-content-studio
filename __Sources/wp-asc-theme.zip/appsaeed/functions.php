<?php

/**
 * title: ASC Theme function
 * author: appsaeed
 * github: https://github.com/appsaeed
 * Email : appsaeed7@gmail.com
 */

define( 'ASC_VERSION', '2.0.1' );
define( 'ASC_TABLE_PREFIX', 'a_' );
define( 'ASC_THEME_PATH', get_template_directory_uri() );
define( 'ASC_REST_PATH', 'asc/v2' );
define( 'ASC_KB', 1024 );
define( 'ASC_MB', 1048576 );
define( 'ASC_GB', 1073741824 );
define( 'ASC_TB', 1099511627776 );

define( 'ASC_FRONTEND_PATH', '/' );

define( 'ASC_JWT_SECRET', 'my_jwt_key' );
define( 'ASC_JWT_HASHED', 'HS256' );
define( 'ASC_JWT_EXPIRE', time() + ( 3600 * 24 ) * 36 );

define( 'ASC_POST_PER_PAGE', '15' );

define( 'ASC_AUTH_COOKINE_NAME', 'asc_rest_api' );
define( 'ASC_AUTH_COOKINE_TIME', ASC_JWT_EXPIRE );
define( 'ASC_AUTH_COOKINE_HOST', '' );
define( 'ASC_AUTH_COOKINE_PATH', '/' );

define( 'ASC_BASIC_AUTH_KEY', 'YXBwc2FlZWQ6ZWpNOCBjMTFoIEE4bG8gSnE1UCB5YzFLIGZDVVA=' );

require_once 'vendor/autoload.php';

use App\database\Database;
use App\theme\Theme;

// In your server-side PHP code
header( "Access-Control-Allow-Origin: http://localhost:3000" );
header( "Access-Control-Allow-Methods: GET, POST, OPTIONS" );
header( "Access-Control-Allow-Headers: Content-Type, Authorization" );
header( "Access-Control-Allow-Credentials: true" );

// Your API logic goes here
// ...

// If it's a preflight request, respond with 200 OK
if ( $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {
    header( "HTTP/1.1 200 OK" );
    exit();
}

//database connection
Database::createConnection();
Database::createSchema( true );
Database::seeder();
Theme::setup();
Theme::api();

/**
 * show application password for rest api authentication
 */
add_filter( 'wp_is_application_passwords_available', '__return_true' );

/***
 * hide/disable admin bar for all user
 */
add_filter( 'show_admin_bar', '__return_false' );

/**
 * make asset function to add style and javascript src
 */
function assets( $path = '', $version = ASC_VERSION ) {
    echo ASC_THEME_PATH . $path . '?v=' . $version;
}

/**
 * use theme directory without echo
 */
function mixup( $path = '', $version = ASC_VERSION ) {
    return ASC_THEME_PATH . $path . '?v=' . $version;
}
