open api key
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

my open api key
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

OPEN AI account

login:
rightwriteworks@gmail.com

password
k7Aq&G5AzqJm

https://rightwrite.io/wp-admin/index.php
wp user: rightwrite
wp pass: rightwriteworks@gmail.com

example key: Create a story about two small bears lost in the forest

https://es6.siteground.eu/phpmyadmin/index.php?route=/&route=%2F&lang=en

https://es6.siteground.eu/phpmyadmin/index.php?route=/database/structure&server=1&db=dbrt46dkn4xm1g
open api key
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

my open api key
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

OPEN AI account

login:
rightwriteworks@gmail.com

password
k7Aq&G5AzqJm

https://rightwrite.io/wp-admin/index.php
wp user: rightwrite
wp pass: rightwriteworks@gmail.com

example key: Create a story about two small bears lost in the forest

https://es6.siteground.eu/phpmyadmin/index.php?route=/&route=%2F&lang=en

https://es6.siteground.eu/phpmyadmin/index.php?route=/database/structure&server=1&db=dbrt46dkn4xm1g
