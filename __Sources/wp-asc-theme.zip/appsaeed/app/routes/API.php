<?php

/**
 * title: api roues make
 * author: appsaeed
 * github: https://github.com/appsaeed
 * Email : appsaeed7@gmail.com
 */

namespace App\routes;

use App\Controllers\Api\AIHomeController;
use App\Controllers\Api\AuthController;
use App\Controllers\Api\ContentController;
use App\Controllers\Api\DashboardController;
use App\Controllers\Api\DocumentController;
use App\Controllers\Api\ImageController;
use App\Controllers\Api\PaymentController;
use App\Controllers\Api\PlanController;
use App\Controllers\Api\PostController;
use App\Controllers\Api\PurchaseLogController;
use App\Controllers\Api\SubscriptionController;
use App\Controllers\Api\SupportController;
use App\Controllers\Api\TestContoller;
use App\Controllers\GeneralController;
use App\helpers\Auth;

class API {
    public static function map() {

        add_action( 'rest_api_init', function () {

            Route::guest( 'home_sections', [new ContentController(), 'index'] );
            Route::guest( 'favicon', [new GeneralController(), 'favicon'] );
            Route::guest( 'logo', [new GeneralController(), 'favicon'] );

            Route::guest( 'test', [new TestContoller(), 'index'] );
            //posts
            Route::guest( 'post', [new PostController(), 'post'] );
            Route::guest( 'posts', [new PostController(), 'posts'] );

            //auth
            Route::post( 'user', [new AuthController(), 'user'], false );
            Route::guest( 'signup', [new AuthController(), 'signup'], 'POST' );
            Route::guest( 'login', [new AuthController(), 'login'], "POST" );
            Route::guest( 'logout', [new AuthController(), 'logout'] );
            Route::guest( 'forget-password', [new AuthController(), 'forgetPassword'], "POST" );
            Route::guest( 'password-reset', [new AuthController(), 'passwordReset'], "POST" );

            //posts routes
            Route::post( 'messages', [new AIHomeController(), 'messages'], false );
            Route::get( 'post_by_url', [new AIHomeController(), 'get_post_by_url'] );
            Route::get( 'page_by_path', [new AIHomeController(), 'page_by_path'] );

            /**
             * Get all plans for guest
             * dashboard api for subscrption
             */
            Route::guest( 'plans', [new PlanController(), 'all'] );
            //dashboard
            Route::get( 'dashboard', [new DashboardController(), 'index'] );

            Route::post( 'checkout/stripe', [new PaymentController(), 'stripeCharge'] );
            Route::get( 'subscription', [new SubscriptionController(), 'activeSubscription'] );
            Route::get( 'subscription/cancel', [new SupportController(), 'cancel'] );

            //images
            Route::get( 'images', [new ImageController(), 'index'] );
            Route::post( 'image/create', [new ImageController(), 'create'] );
            Route::post( 'image/delete', [new ImageController(), 'delete'] );
            //docuemnts
            Route::get( 'documents', [new DocumentController(), 'index'] );
            Route::get( 'documents/test', [new DocumentController(), 'test'] );
            Route::post( 'documents/create', [new DocumentController(), 'create'] );
            Route::post( 'documents/delete', [new DocumentController(), 'delete'] );
            Route::post( 'documents/archive', [new DocumentController(), 'archive'] );
            Route::post( 'documents/update', [new DocumentController(), 'update'] );

            //Support
            Route::get( 'supports', [new SupportController(), 'index'] );
            Route::post( 'supports/reply', [new SupportController(), 'reply'] );
            Route::post( 'supports/create', [new SupportController(), 'create'] );

            //purchase log
            Route::get( 'purchase', [new PurchaseLogController(), 'index'] );

            //test route
        } );
    }
}

/**
 * create a class for define api router
 * @method Route
 */
class Route {

    public static function guest( string $path, $callback, $method = 'GET' ) {
        register_rest_route(
            ASC_REST_PATH,
            $path,
            [
                'methods' => $method,
                'callback' => $callback,
                'permission_callback' => "__return_true",
            ]
        );
    }

    public static function get( string $path, $callback, $protected = true ) {
        register_rest_route(
            ASC_REST_PATH,
            $path,
            [
                'methods' => 'GET',
                'callback' => $callback,
                'permission_callback' => function () use ( $protected ) {
                    if ( !$protected ) {
                        return true;
                    }
                    return Auth::isLogin();
                },

            ]
        );
    }

    public static function post( $path, $callback, $protected = true ) {
        register_rest_route(
            ASC_REST_PATH,
            $path,
            [
                'methods' => 'POST',
                'callback' => $callback,
                'permission_callback' => function () use ( $protected ) {
                    if ( !$protected ) {
                        return true;
                    }
                    return Auth::isLogin();
                },
            ]
        );
    }
}
