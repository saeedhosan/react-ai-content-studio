<?php

namespace App\helpers;

use App\config\Settings;

class Mail
{

    public static function to(string $to, string $subject, array $data = [], string $contentType = 'text/html', array $attachments = [])
    {
        try {
            $message = $subject;
            $headers = array('Content-Type: ' . $contentType . '; charset=\"utf-8\"\r\n');
            wp_mail($to, $subject, $message, $headers, $attachments);
            return true;
        } catch (\Throwable $th) {
            return null;
        }
    }
    public static function template(string $message, array $data = []): string
    {
        //make ready for email template 
        $email    = isset($data['email']) ? $data['email'] : '';

?>

        <!DOCTYPE html>
        <html>

        <head>
            <meta name="viewport" content="width=device-width,initial-scale=1" />
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <title>App mail</title>
        </head>

        <style>
            .preheader {
                color: transparent;
                display: none;
                height: 0;
                max-height: 0;
                max-width: 0;
                opacity: 0;
                overflow: hidden;
                mso-hide: all;
                visibility: hidden;
                width: 0;
            }

            table {
                border: 0;
                border-collapse: separate;
                mso-table-lspace: 0;
                background-color: #f6f6f6;
                width: 100%;
            }

            .container {
                font-family: sans-serif;
                font-size: 14px;
                vertical-align: top;
                display: block;
                max-width: 580px;
                padding: 10px;
                width: 580px;
                margin: 0 auto;
            }

            .content {
                box-sizing: border-box;
                display: block;
                margin: 0 auto;
                max-width: 580px;
                padding: 10px;
            }

            .wrapper {
                font-family: sans-serif;
                font-size: 14px;
                vertical-align: top;
                box-sizing: border-box;
                padding: 26px;
            }

            .list {
                list-style: none;
                margin: 0;
                padding: 0;
                width: 100%;
            }

            .list li {
                width: 100%;
                display: flex;
                padding: 6px 0
            }

            .content-block {}
        </style>

        <body>

            <span class="preheader">
                some message here
            </span>
            <table class="presentation">
                <tr>
                    <td class="container">
                        <div class="content">
                            <table>
                                <tr>
                                    <td class="wrapper">
                                        <table class="presentation">
                                            <tr>
                                                <td>
                                                    <h3> message</h3>
                                                    <br />
                                                    <ul class="list">
                                                        <h3>Details</h3>
                                                        <li>
                                                            <div>
                                                                key
                                                            </div>
                                                            <div>value</div>
                                                        </li>
                                                    </ul>
                                                    <br />
                                                    <b>
                                                        Good luck!
                                                    </b>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            <div class="footer" style="
                clear: both;
                margin-top: 10px;
                text-align: center;
                width: 100%;
              ">
                                <table style="
                  border-collapse: separate;
                  mso-table-lspace: 0;
                  mso-table-rspace: 0;
                  width: 100%;
                ">
                                    <tr>
                                        <td class="content-block" style="
                      font-family: sans-serif;
                      vertical-align: top;
                      padding-bottom: 10px;
                      padding-top: 10px;
                      color: #999;
                      font-size: 12px;
                      text-align: center;
                    ">
                                            Don't like these emails?<a href="" style="
                        text-decoration: underline;
                        color: #999;
                        font-size: 12px;
                        text-align: center;
                      ">Unsubscribe</a>.
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="content-block powered-by" style="
                      font-family: sans-serif;
                      vertical-align: top;
                      padding-bottom: 10px;
                      padding-top: 10px;
                      color: #999;
                      font-size: 12px;
                      text-align: center;
                    " valign="top" align="center">
                                            Powered by<a href="https://github.com/appsaeed" style="
                        color: #999;
                        font-size: 12px;
                        text-align: center;
                        text-decoration: none;
                      ">Appsaeed</a>.
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </body>

        </html>


<?php
        return '';
    }
}
?>