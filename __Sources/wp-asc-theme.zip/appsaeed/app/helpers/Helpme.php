<?php

namespace App\helpers;

class Helpme
{

    /**
     * @method url_exists check url exits
     * @return bool
     */
    public static function  url_exists($url)
    {
        return curl_init($url) !== false;
    }
}
