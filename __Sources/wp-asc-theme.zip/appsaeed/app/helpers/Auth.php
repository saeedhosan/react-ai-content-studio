<?php

namespace App\helpers;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class Auth
{
    public static function set(string $username, $remember)
    {
        try {

            $payload = [
                'username' => $username,
                'exp_time' => ASC_JWT_EXPIRE,
            ];

            $jwt = JWT::encode($payload, ASC_JWT_SECRET, 'HS256');

            setcookie(ASC_AUTH_COOKINE_NAME, $jwt, ASC_AUTH_COOKINE_TIME, ASC_AUTH_COOKINE_PATH, ASC_AUTH_COOKINE_HOST);

            return $jwt;

            //jwt
        } catch (\Throwable $th) {
            return null;
        }
        return null;
    }

    public static function unset()
    {
        setcookie(ASC_AUTH_COOKINE_NAME, '', time() - 60, ASC_AUTH_COOKINE_PATH, ASC_AUTH_COOKINE_HOST);
    }

    public static function user()
    {
        $user =  null;
        try {
            //checking cookie
            $jwt = isset($_COOKIE[ASC_AUTH_COOKINE_NAME]) ? $_COOKIE[ASC_AUTH_COOKINE_NAME] : null;

            //decode token
            $decoded = (array) JWT::decode($jwt, new Key(ASC_JWT_SECRET, 'HS256'));

            //check property 
            $expired = isset($decoded['exp_time']) ? $decoded['exp_time'] : 0;
            $username = isset($decoded['username']) ? $decoded['username'] : null;
            $user_obj = get_user_by('login', $username);

            if ($jwt && $expired > time() && $username && $user_obj) {
                $user = (object) [
                    'user__id' => $user_obj->data->ID,
                    'nickname' => $user_obj->data->display_name,
                    'username' => $user_obj->data->user_login,
                    'usermail' => $user_obj->data->user_email,
                    'user_img' => get_avatar_url($user_obj->ID),
                    'user_jwt' => $jwt,
                ];
            }
        } catch (\Throwable $th) {
            $user = null;
        }

        return $user;
    }

    public static function isLogin()
    {
        return self::user() ? true : false;
    }

    public static function id()
    {
        $user_id = 0;
        $user    = self::user();
        if ($user && property_exists($user, 'user__id')) {
            $user_id = intval($user->user__id);
        }
        return $user_id;
    }
}
