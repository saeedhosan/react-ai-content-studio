<?php

namespace App\helpers;

use WP_REST_Response;
use WP_REST_Request;
use WP_Error;


class Response
{
    /**
     * @param string|array $data
     * @param int $status
     * @param array $headers
     * @return \WP_REST_Response
     */
    public function success(string|array|null $data, int $status = 200, $headers = []): WP_REST_Response
    {
        $response = [];
        if (gettype($data) === 'string') {
            $response = [
                'success' => true,
                'message' => $data
            ];
        } elseif (!$data) {
            $response = [
                'success' => true,
                'data' => null
            ];
        } else {
            $response = [
                'success' => true,
                'data'    => $data
            ];
        }

        return new WP_REST_Response($response, $status, $headers);
    }

    /**
     * @method error response
     * @param string $message — Error message.
     * @param string|int $code — Error code.
     * @param mixed $data — Optional. Error data.
     * @return \WP_Error 
     */
    public function error(string $message, int $code = 500, array $data = []): WP_Error
    {
        return new WP_Error($code, $message, $data);
    }


    /**
     * asc api response
     * @param mixed $data
     * @param int $status
     * @param array $headers
     * @return \WP_REST_Response
     */
    public function response($data, int $status = 200, array $headers = []): WP_REST_Response
    {
        return  new WP_REST_Response($data, $status, $headers);
    }
}
