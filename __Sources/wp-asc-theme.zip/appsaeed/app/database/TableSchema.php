<?php
namespace App\database;

use App\Models\AppPassword;
use App\Models\Content;
use App\Models\Document;
use App\Models\Images;
use App\Models\Plans;
use App\Models\PurchaseLog;
use App\Models\Subscriptions;
use App\Models\User;
use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

class TableSchema {

    /**
     * @param bool $force force to create table schema
     * Create a all schemas
     */
    public static function migrate( bool $force = false ) {

        self::planSchema( $force );
        self::imageSchema( $force );
        self::subscriptionSchema( $force );
        self::purchaseLogSchema( $force );
        self::documentSchema( $force );
        self::appPasswordSchema( $force );

    }

    /**
     * @param bool $force force to create table schema
     * @return string
     */
    public static function userTable() {
        return ( new User() )->getTable();
    }

    /**
     * @param bool $force force to create table schema
     * Create plan table schema
     */
    public static function planSchema( bool $force = false ) {

        //get plan table name help of table model
        $table_name = ( new Plans() )->getTable();

        if ( $force ) {

            //drop table schema and make ready for create new schema
            Capsule::schema()->disableForeignKeyConstraints();
            Capsule::schema()->dropIfExists( $table_name );

        } elseif ( Capsule::schema()->hasTable( $table_name ) ) {

            return false;

        }

        // Create a migration for your table
        Capsule::schema()->create( $table_name, function ( Blueprint $table ) {

            $table->id();
            $table->uuid( 'uid' )->nullable();
            $table->integer( 'user_id' )->nullable();
            $table->string( 'name' );
            $table->string( 'slug' )->nullable();
            $table->integer( 'words' );
            $table->integer( 'images' );
            $table->string( 'description' )->nullable();
            $table->decimal( 'price' );
            $table->enum( 'billing_cycle', ['daily', 'weekly', 'monthly', 'yearly', 'custom'] )->default( 'monthly' )->nullable();
            $table->string( 'frequency_unit' );
            $table->string( 'items' )->nullable();
            $table->integer( 'custom_ordered' )->nullable();
            $table->boolean( 'is_default' )->default( false );
            $table->boolean( 'is_popular' )->default( false );
            $table->longText( 'options' )->nullable();

            $table->timestamps();
        } );
    }

    /**
     * @param bool $force force to create table schema
     * Image schema
     */
    public static function imageSchema( bool $force = false ) {

        $table_name = ( new Images() )->getTable();

        if ( $force ) {

            //drop table schema and make ready for create new schema
            Capsule::schema()->disableForeignKeyConstraints();
            Capsule::schema()->dropIfExists( $table_name );

        } elseif ( Capsule::schema()->hasTable( $table_name ) ) {

            return false;

        }

        Capsule::schema()->create( $table_name, function ( Blueprint $table ) {

            $table->id();
            $table->uuid( 'uid' )->nullable();
            $table->unsignedBigInteger( 'user_id' );
            $table->unsignedBigInteger( 'subscription_id' );
            $table->text( 'url' )->nullable();
            $table->text( 'path' )->nullable();
            $table->string( 'name' )->nullable();
            $table->text( 'size' )->nullable();
            $table->text( 'type' )->nullable();
            $table->string( 'title' )->nullable();
            $table->text( 'description' )->nullable();
            $table->longText( 'data' )->nullable();

            $table->timestamps();

            $table->foreign( 'user_id' )->references( 'id' )->on( 'users' )->onDelete( 'cascade' );

        } );

    }

    /**
     * @param bool $force force to create table schema
     * Create Subscription schema table
     *
     */
    public static function subscriptionSchema( bool $force = false ) {

        //get table name from model
        $table_name = ( new Subscriptions() )->getTable();

        if ( $force ) {

            //drop table schema and make ready for create new schema
            Capsule::schema()->disableForeignKeyConstraints();
            Capsule::schema()->dropIfExists( $table_name );

        } elseif ( Capsule::schema()->hasTable( $table_name ) ) {

            return false;

        }

        Capsule::schema()->create( $table_name, function ( Blueprint $table ) {
            $table->id();
            $table->uuid( 'uid' )->nullable();

            $table->unsignedBigInteger( 'user_id' );
            $table->unsignedBigInteger( 'plan_id' );
            $table->string( 'payment_method' )->nullable();
            $table->string( 'words' );
            $table->string( 'images' );
            $table->string( 'documents' )->nullable();
            $table->longText( 'options' )->nullable();
            $table->enum( 'status', [
                'new', 'pending', 'paid', 'active', 'cancel', 'renew', 'ended',
            ] )->default( 'new' );
            $table->boolean( 'paid' )->default( false );
            $table->boolean( 'payment_claimed' )->default( false );
            $table->dateTime( 'current_period_ends_at' )->nullable();
            $table->dateTime( 'start_at' )->nullable();
            $table->dateTime( 'end_at' )->nullable();

            $table->timestamps();

            //get plan table name from model
            $plan_table = ( new Plans() )->getTable();

            //get user table name from model
            $user_table = ( new User() )->getTable();

            $table->foreign( 'user_id' )->references( 'id' )->on( $user_table )->onDelete( 'cascade' );
            $table->foreign( 'plan_id' )->references( 'id' )->on( $plan_table )->onDelete( 'cascade' );

        } );

    }

    /**
     * @param bool $force force to create table schema
     * Create wordpress app password schema
     */
    public static function appPasswordSchema( bool $force = false ) {

        //get table name from model
        $table_name = ( new AppPassword() )->getTable();

        if ( $force ) {

            //drop table schema and make ready for create new schema
            Capsule::schema()->disableForeignKeyConstraints();
            Capsule::schema()->dropIfExists( $table_name );

        } elseif ( Capsule::schema()->hasTable( $table_name ) ) {

            return false;

        }

        Capsule::schema()->create( $table_name, function ( Blueprint $table ) {

            $table->id();
            $table->uuid( 'uid' )->nullable();
            $table->unsignedBigInteger( 'user_id' );
            $table->text( 'username' )->nullable();
            $table->text( 'password' )->nullable();
            $table->text( 'pass_uid' )->nullable();
            $table->text( 'last_key' )->nullable();
            $table->text( 'expired' )->nullable();
            $table->text( 'options' )->nullable();
            $table->text( 'status' )->nullable();

            $table->timestamps();

            //get user table name from model
            $user_table = ( new User() )->getTable();

            $table->foreign( 'user_id' )->references( 'id' )->on( $user_table )->onDelete( 'cascade' );

        } );
    }

    /**
     * @param bool $force force to create table schema
     * Create Document table schema
     */
    public static function documentSchema( bool $force = false ) {

        //get document table name from model
        $table_name = ( new Document() )->getTable();

        if ( $force ) {

            //drop table schema and make ready for create new schema
            Capsule::schema()->disableForeignKeyConstraints();
            Capsule::schema()->dropIfExists( $table_name );

        } elseif ( Capsule::schema()->hasTable( $table_name ) ) {

            return false;

        }

        Capsule::schema()->create( $table_name, function ( Blueprint $table ) {

            $table->id();
            $table->uuid( 'uid' )->nullable();
            $table->unsignedBigInteger( 'user_id' );
            $table->text( 'blog_name' )->nullable();
            $table->text( 'blog_title' )->nullable();
            $table->text( 'docs_name' )->nullable();
            $table->text( 'word_used' )->nullable();
            $table->text( 'language' )->nullable();
            $table->text( 'text' )->nullable();
            $table->text( 'html' )->nullable();
            $table->longText( 'response' )->nullable();
            $table->longText( 'options' )->nullable();
            $table->boolean( 'status' )->nullable();

            $table->timestamps();

            //get user table name from model
            $user_table = ( new User() )->getTable();

            $table->foreign( 'user_id' )->references( 'id' )->on( $user_table )->onDelete( 'cascade' );
        } );
    }

    /**
     * @param bool $force force to create table schema
     * Create Purchase log table schema
     */
    public static function purchaseLogSchema( bool $force = false ) {

        //get purchaseLog table name from model
        $table_name = ( new PurchaseLog() )->getTable();

        if ( $force ) {

            //drop table schema and make ready for create new schema
            Capsule::schema()->disableForeignKeyConstraints();
            Capsule::schema()->dropIfExists( $table_name );

        } elseif ( Capsule::schema()->hasTable( $table_name ) ) {

            return false;

        }

        Capsule::schema()->create( $table_name, function ( Blueprint $table ) {

            $table->id();
            $table->uuid( 'uid' )->nullable();
            $table->unsignedBigInteger( 'user_id' );
            $table->longText( 'plan' )->nullable();
            $table->longText( 'subscription' )->nullable();
            $table->string( 'words' )->nullable();
            $table->string( 'images' )->nullable();
            $table->string( 'price' )->nullable();
            $table->string( 'plan_id' )->nullable();
            $table->string( 'plan_name' )->nullable();
            $table->string( 'subscription_id' )->nullable();
            $table->string( 'payment_method' )->nullable();
            $table->enum( 'status', ['new', 'pending', 'active', 'ended', 'renew'] )->default( 'new' );

            $table->timestamps();

            //get user table name from model
            $user_table = ( new User() )->getTable();

            $table->foreign( 'user_id' )->references( 'id' )->on( $user_table )->onDelete( 'cascade' );

        } );
    }

    public static function contentSchema( bool $force = false ) {

        //get purchaseLog table name from model
        $table_name = ( new Content() )->getTable();

        if ( $force ) {

            //drop table schema and make ready for create new schema
            Capsule::schema()->disableForeignKeyConstraints();
            Capsule::schema()->dropIfExists( $table_name );

        } elseif ( Capsule::schema()->hasTable( $table_name ) ) {

            return false;

        }

        Capsule::schema()->create( $table_name, function ( Blueprint $table ) {

            $table->id();
            $table->uuid( 'uid' )->nullable();
            $table->integer( 'user_id' )->nullable();
            $table->string( 'key' );
            $table->longText( 'data' )->nullable();
            $table->longText( 'value' )->nullable();
            $table->string( 'type' )->nullable();

            $table->timestamps();

        } );
    }
}