<?php

namespace App\database;

use App\Models\Content;
use App\Models\Plans;

class Seeder {

    public static function planSeeder() {

        if ( Plans::count() === 0 ) {
            foreach ( self::planData() as $plan ) {

                // $plan['uid'] = uniqid();

                Plans::create( $plan );

            }
        }

    }

    public static function contentSeeder( bool $fore = false ) {

        Content::create( [
            'key' => 'home_sections',
            'type' => 'section_content',
            'value' => json_encode( [
                'hero_section' => [
                    'content' => [
                        'welcome' => 'Premium Content In Seconds',
                        'title' => 'AI Sources content creator',
                        'typing' => [
                            0 => '<h2><span class=\'\'>Premium Quality Content</h2>',
                            1 => '<h2><span class=\'\'>Engaging Blog Posts</span></h2>',
                            2 => '<h2><span class=\'\'>Amazing SEO Content</span></h2>',
                            3 => '<h2><span class=\'\'>Creative Content Ideas</span></h2>',
                            4 => '<h2><span class=\'\'>Authority Content</span></h2>',
                            5 => '<h2><span class=\'\'>Premium Quality Images</span></h2>',
                            6 => '<h2><span class=\'\'>And So Much More!</span></h2>',
                        ],
                        'description' => 'Start your business with us today!',
                        'button_text' => 'Starn Now',
                        'bgImage' => 'https://images.unsplash.com/photo-1541280910158-c4e14f9c94a3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80',
                    ],
                ],
                'feature_section' => [
                    'content' => [
                        'title' => '{{app_name}} Overview',
                        'text' => '{{app_name}} creates premium content for you in seconds.',
                        'bg_image' => '',
                        'bg_color' => '',
                    ],
                    'features' => [
                        0 => [
                            'name' => 'PREMIUM QUALITY CONTENT',
                            'content' => 'Amazing content in seconds.',
                            'box_theme' => 'light',
                            'image' => 'http://localhost/wordpress.com/wp-content/themes/appsaeed/assets/images/features-01.png?v=2.0.1',
                            'aos' => [
                                'zoom' => 'zoom-in',
                                'delay' => 400,
                                'once' => true,
                                'duration' => 700,
                            ],
                        ],
                        1 => [
                            'name' => 'ACCURATE AND FAST',
                            'content' => 'Engaging and precise writing.',
                            'box_theme' => 'dark',
                            'image' => 'https://write4me.co/img/files/09.png',
                            'aos' => [
                                'zoom' => 'zoom-in',
                                'delay' => 400,
                                'once' => true,
                                'duration' => 700,
                            ],
                        ],
                        2 => [
                            'name' => 'COST EFFECTIVE',
                            'content' => 'Extremely affordable, premium content.',
                            'box_theme' => 'dark',
                            'image' => 'http://localhost/wordpress.com/wp-content/themes/appsaeed/assets/images/features-03.png?v=2.0.1',
                            'aos' => [
                                'zoom' => 'zoom-in',
                                'delay' => 400,
                                'once' => true,
                                'duration' => 700,
                            ],
                        ],
                        3 => [
                            'name' => 'CREATIVE CONTENT IDEAS',
                            'content' => 'Never suffer from writer\'s block again.',
                            'box_theme' => 'light',
                            'image' => 'http://localhost/wordpress.com/wp-content/themes/appsaeed/assets/images/features-04.png?v=2.0.1',
                            'aos' => [
                                'zoom' => 'zoom-in',
                                'delay' => 400,
                                'once' => true,
                                'duration' => 700,
                            ],
                        ],
                        4 => [
                            'name' => 'PREMIUM IMAGES',
                            'content' => 'Generate images to illustrate your writing.',
                            'box_theme' => 'light',
                            'image' => 'http://localhost/wordpress.com/wp-content/themes/appsaeed/assets/images/features-05.png?v=2.0.1',
                            'aos' => [
                                'zoom' => 'zoom-in',
                                'delay' => 400,
                                'once' => true,
                                'duration' => 700,
                            ],
                        ],
                        5 => [
                            'name' => 'and much more!',
                            'content' => 'Your possibilities are endless.',
                            'box_theme' => 'dark',
                            'image' => 'http://localhost/wordpress.com/wp-content/themes/appsaeed/assets/images/features-06.png?v=2.0.1',
                            'aos' => [
                                'zoom' => 'zoom-in',
                                'delay' => 400,
                                'once' => true,
                                'duration' => 700,
                            ],
                        ],
                    ],
                ],
                'template_section' => [
                    'content' => [
                        'title' => 'Unlimited Content Types',
                        'text' => 'Your options are endless. Here are just a few.',
                    ],
                    'templates' => [
                        0 => [
                            '_url' => 'blog-titles',
                            'name' => 'Blog Titles',
                            'icon' => 'fa-solid fa-message-text blog-icon',
                            'text' => 'Make blogging fast and easy with {{app_name}}. Get creative, fresh titles with our state of the art technology!',
                            'category' => 'blog',
                        ],
                        1 => [
                            '_url' => 'blog-sections',
                            'name' => 'Blog Sections',
                            'icon' => 'fa-solid fa-message-lines blog-icon',
                            'text' => 'Unlock the power of incredible blog sections - organize your blog posts quickly and easily, without lifting a finger.',
                            'category' => 'blog',
                        ],
                        2 => [
                            '_url' => 'blog-ideas',
                            'name' => 'Blog Ideas',
                            'icon' => 'fa-solid fa-message-dots blog-icon',
                            'text' => 'Explore the world of blogging with us! Get great blog ideas and create content with ease.',
                            'category' => 'blog',
                        ],
                        3 => [
                            '_url' => 'blog-intros',
                            'name' => 'Blog Intros',
                            'icon' => 'fa-solid fa-message-exclamation blog-icon',
                            'text' => 'Write great blog intros in seconds - {{app_name}} creates the perfect starts to your blog posts!',
                            'category' => 'blog',
                        ],
                        4 => [
                            '_url' => 'blog-conclusions',
                            'name' => 'Blog Conclusions',
                            'icon' => 'fa-solid fa-message-check blog-icon',
                            'text' => 'Grow your audience and get great blog post conclusions that leave your readers wanting more!',
                            'category' => 'blog',
                        ],
                        5 => [
                            '_url' => 'welcome-emails',
                            'name' => 'Welcome Emails',
                            'icon' => 'fa-solid fa-envelope-open-text main-icon',
                            'text' => 'Experience the power of great welcome emails! Make your customers feel special with personalized email copy.',
                            'category' => 'email',
                        ],
                        6 => [
                            '_url' => 'cold-emails',
                            'name' => 'Cold Emails',
                            'icon' => 'fa-solid fa-mailbox main-icon',
                            'text' => 'Get great cold emails now! Just click a button and have {{app_name}} write it for you!',
                            'category' => 'email',
                        ],
                        7 => [
                            '_url' => 'flow-up-emails',
                            'name' => 'Follow-Up Emails',
                            'icon' => 'fa-solid fa-reply-all main-icon',
                            'text' => 'Amazing follow up emails have never been so easy! Experience the power of AI right now.',
                            'category' => 'email',
                        ],
                        8 => [
                            '_url' => 'amazon-product-description',
                            'name' => 'Amazon Product Descriptions',
                            'icon' => 'fa-brands fa-amazon other-icon',
                            'text' => 'Are you selling products on Amazon? Generate money making descriptions in seconds!',
                            'category' => 'other',
                        ],
                        9 => [
                            '_url' => 'facebook-ads',
                            'name' => 'Facebook Ads',
                            'icon' => 'fa-brands fa-facebook social-icon',
                            'text' => 'Quickly create high converting Facebook Ad copy without any of the headaches.',
                            'category' => 'social-media',
                        ],
                        10 => [
                            '_url' => 'instagram-captions',
                            'name' => 'Instagram Captions',
                            'icon' => 'fa-brands fa-instagram social-icon',
                            'text' => 'Engage with your audience on Instagram with intriguing captions written for you by {{app_name}}',
                            'category' => 'social-media',
                        ],
                        11 => [
                            '_url' => 'instagram-hashtags-generator',
                            'name' => 'Instagram Hashtags Generator',
                            'icon' => 'fa-brands fa-instagram social-icon',
                            'text' => 'Don\'t know what hashtags to use to make your Instagram posts easy to find? Let {{app_name}} do it for you!',
                            'category' => 'social-media',
                        ],
                        12 => [
                            '_url' => 'social-media-posts-personal',
                            'name' => 'Social Media Posts (Personal)',
                            'icon' => 'fa-solid fa-thumbs-up social-icon',
                            'text' => 'Create scroll stopping social media posts for your personal feeds and pages… all in a few clicks of a button!',
                            'category' => 'social-media',
                        ],
                        13 => [
                            '_url' => 'socail-media-posts-business',
                            'name' => 'Social Media Posts (Business)',
                            'icon' => 'fa-solid fa-thumbs-up social-icon',
                            'text' => 'Create scroll stopping social media posts for your business feeds and pages… all in a few clicks of a button!',
                            'category' => 'social-media',
                        ],
                        14 => [
                            '_url' => 'facebook-headlines',
                            'name' => 'Facebook Headlines',
                            'icon' => 'fa-brands fa-facebook social-icon',
                            'text' => 'Generate amazing, eyeball grabbing Facebook headlines in seconds right inside your {{app_name}} account.',
                            'category' => 'social-media',
                        ],
                        15 => [
                            '_url' => 'google-ads-headlines',
                            'name' => 'Google Ads Headlines',
                            'icon' => 'fa-brands fa-google social-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'social-media',
                        ],
                        16 => [
                            '_url' => 'google-ads-description',
                            'name' => 'Google Ads Description',
                            'icon' => 'fa-brands fa-google social-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'social-media',
                        ],
                        17 => [
                            '_url' => 'article-generator',
                            'name' => 'Article Generator',
                            'icon' => 'fa-solid fa-file-lines main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        18 => [
                            '_url' => 'content-rewriter',
                            'name' => 'Content Rewriter',
                            'icon' => 'fa-solid fa-square-check main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        19 => [
                            '_url' => 'paragraph-generator',
                            'name' => 'Paragraph Generator',
                            'icon' => 'fa-solid fa-line-columns main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        20 => [
                            '_url' => 'talking-points',
                            'name' => 'Talking Points',
                            'icon' => 'fa-solid fa-list-check main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        21 => [
                            '_url' => 'pros-and-cons',
                            'name' => 'Pros & Cons',
                            'icon' => 'fa-solid fa-code-compare main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        22 => [
                            '_url' => 'summarize-text',
                            'name' => 'Summarize Text',
                            'icon' => 'fa-solid fa-file-contract main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        23 => [
                            '_url' => 'product-description',
                            'name' => 'Product Description',
                            'icon' => 'fa-solid fa-list-check main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        24 => [
                            '_url' => 'startup-name-generator',
                            'name' => 'Startup Name Generator',
                            'icon' => 'fa-solid fa-lightbulb-on main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        25 => [
                            '_url' => 'product-name-generator',
                            'name' => 'Product Name Generator',
                            'icon' => 'fa-solid fa-box-circle-check main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'blog',
                        ],
                        26 => [
                            '_url' => 'academic-essay',
                            'name' => 'Academic Essay',
                            'icon' => 'fa-solid fa-scroll-old main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        27 => [
                            '_url' => 'creative-stories',
                            'name' => 'Creative Stories',
                            'icon' => 'fa-solid fa-books main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        28 => [
                            '_url' => 'summarize-for-2nd-grader',
                            'name' => 'Summarize for 2nd Grader',
                            'icon' => 'fa-solid fa-thought-bubble main-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'content',
                        ],
                        29 => [
                            '_url' => 'video-descriptions',
                            'name' => 'Video Descriptions',
                            'icon' => 'fa-brands fa-youtube blog-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'video',
                        ],
                        30 => [
                            '_url' => 'video-title',
                            'name' => 'Video Titles',
                            'icon' => 'fa-brands fa-youtube blog-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'video',
                        ],
                        31 => [
                            '_url' => 'youtube-tags-generator',
                            'name' => 'Youtube Tags Generator',
                            'icon' => 'fa-brands fa-youtube blog-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'video',
                        ],
                        32 => [
                            '_url' => 'video-scripts',
                            'name' => 'Video Scripts',
                            'icon' => 'fa-solid fa-film blog-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'video',
                        ],
                        33 => [
                            '_url' => 'meta-description',
                            'name' => 'Meta Description',
                            'icon' => 'fa-solid fa-memo-circle-info web-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'website',
                        ],
                        34 => [
                            '_url' => 'faqs',
                            'name' => 'FAQs',
                            'icon' => 'fa-solid fa-message-question web-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'website',
                        ],
                        35 => [
                            '_url' => 'faq-answers',
                            'name' => 'FAQ Answers',
                            'icon' => 'fa-solid fa-messages-question web-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'website',
                        ],
                        36 => [
                            '_url' => 'testimonials-reviews',
                            'name' => 'Testimonials / Reviews',
                            'icon' => 'fa-solid fa-star-sharp-half-stroke web-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'website',
                        ],
                        37 => [
                            '_url' => 'problem-agitate-solution',
                            'name' => 'Problem Agitate Solution',
                            'icon' => 'fa-solid fa-copyright web-icon',
                            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                            'category' => 'website',
                        ],
                    ],
                    'categories' => [
                        0 => 'all',
                        1 => 'content',
                        2 => 'blog',
                        3 => 'website',
                        4 => 'social-media',
                        5 => 'email',
                        6 => 'video',
                        7 => 'other',
                    ],
                ],
                'plan_section' => [
                    'content' => [
                        'title' => 'Flexible Plans & Pricing',
                        'text' => 'Choose the best plan for your needs.',
                    ],
                    'plans' => [
                        0 => [
                            'id' => 1,
                            'uid' => NULL,
                            'user_id' => NULL,
                            'name' => 'professional',
                            'slug' => 'professional',
                            'words' => 30000,
                            'images' => 30,
                            'description' => 'This is an professional plan',
                            'price' => '9.97',
                            'billing_cycle' => 'monthly',
                            'frequency_unit' => '1',
                            'items' => '["30, 000 words","30 images","All templates","Unlimited access","Full time support"]',
                            'custom_ordered' => NULL,
                            'is_default' => 1,
                            'is_popular' => 0,
                            'options' => NULL,
                            'created_at' => '2024-01-29T12:42:01.000000Z',
                            'updated_at' => '2024-01-29T12:42:01.000000Z',
                        ],
                        1 => [
                            'id' => 2,
                            'uid' => NULL,
                            'user_id' => NULL,
                            'name' => 'Team',
                            'slug' => 'team',
                            'words' => 300000,
                            'images' => 100,
                            'description' => 'This is an team plan',
                            'price' => '19.97',
                            'billing_cycle' => 'monthly',
                            'frequency_unit' => '1',
                            'items' => '["300, 000 words","100 images","All templates","Unlimited access","Full time support"]',
                            'custom_ordered' => NULL,
                            'is_default' => 0,
                            'is_popular' => 1,
                            'options' => NULL,
                            'created_at' => '2024-01-29T12:42:01.000000Z',
                            'updated_at' => '2024-01-29T12:42:01.000000Z',
                        ],
                        2 => [
                            'id' => 3,
                            'uid' => NULL,
                            'user_id' => NULL,
                            'name' => 'Business',
                            'slug' => 'business',
                            'words' => 600000,
                            'images' => 200,
                            'description' => 'This is an business plan',
                            'price' => '39.97',
                            'billing_cycle' => 'monthly',
                            'frequency_unit' => '1',
                            'items' => '["600, 000 words","200 images","All templates","Unlimited access","Full time support"]',
                            'custom_ordered' => NULL,
                            'is_default' => 0,
                            'is_popular' => 1,
                            'options' => NULL,
                            'created_at' => '2024-01-29T12:42:01.000000Z',
                            'updated_at' => '2024-01-29T12:42:01.000000Z',
                        ],
                    ],
                ],
                'footer_section' => [
                    'content' => [
                        'logo' => NULL,
                        'text' => 'Click away your content worries! Get the perfect words with a single click - no hassle, no stress! Make writing easy and fun!',
                        'column_1' => [
                            'title' => 'About Links',
                            'items' => [
                                0 => [
                                    'name' => 'Account',
                                    '_url' => '/user/dashboard',
                                ],
                                1 => [
                                    'name' => 'Contact',
                                    '_url' => '/contact',
                                ],
                                2 => [
                                    'name' => 'Help',
                                    '_url' => '/Help',
                                ],
                            ],
                        ],
                        'column_2' => [
                            'title' => 'Legal Services',
                            'items' => [
                                0 => [
                                    'name' => 'Privacy Policy',
                                    '_url' => '/privacy-policy',
                                ],
                                1 => [
                                    'name' => 'Terms of Service',
                                    '_url' => '/terms-of-service',
                                ],
                            ],
                        ],
                        'column_3' => [
                            'title' => 'Supports ',
                            'items' => [
                                0 => [
                                    'name' => 'appsaeed7@gmail.com',
                                    '_url' => 'mailto:appsaeed7@gmail.com',
                                ],
                                1 => [
                                    'name' => 'Github Profile',
                                    '_url' => 'https://github.com/appsaeed',
                                ],
                                2 => [
                                    'name' => 'Contact us',
                                    '_url' => '/contact-us',
                                ],
                            ],
                        ],
                    ],
                    'copyright' => [
                        'name' => '',
                        '_url' => '',
                        'items' => [
                            0 => [
                                'name' => 'Terms & Conditions',
                                '_url' => '/terms-and-conditions',
                            ],
                            1 => [
                                'name' => 'Privacy Policy',
                                '_url' => '/privacy-terms',
                                'slug' => '|',
                            ],
                        ],
                    ],
                ],
            ] ),
        ] );

    }

    /**
     * This can be update for customize plans
     * @return array planData
     */
    public static function planData(): array {

        return [
            [
                "name" => 'professional',
                "slug" => 'professional',
                "words" => 30000,
                "images" => 30,
                "description" => 'This is an professional plan',
                "price" => 9.97,
                "billing_cycle" => 'monthly',
                "frequency_unit" => 1,
                "items" => json_encode( [
                    '30, 000 words',
                    '30 images',
                    'All templates',
                    'Unlimited access',
                    'Full time support',
                ] ),
                "is_default" => true,
                "is_popular" => false,
            ],
            [
                "name" => 'Team',
                "slug" => 'team',
                "words" => 300000,
                "images" => 100,
                "description" => 'This is an team plan',
                "price" => 19.97,
                "billing_cycle" => 'monthly',
                "frequency_unit" => 1,
                "items" => json_encode( [
                    '300, 000 words',
                    '100 images',
                    'All templates',
                    'Unlimited access',
                    'Full time support',
                ] ),
                "is_default" => false,
                "is_popular" => true,
            ],
            [
                "name" => 'Business',
                "slug" => 'business',
                "words" => 600000,
                "images" => 200,
                "description" => 'This is an business plan',
                "price" => 39.97,
                "billing_cycle" => 'monthly',
                "frequency_unit" => 1,
                "items" => json_encode( [
                    '600, 000 words',
                    '200 images',
                    'All templates',
                    'Unlimited access',
                    'Full time support',
                ] ),
                "is_default" => false,
                "is_popular" => true,
            ],

        ];

    }

}