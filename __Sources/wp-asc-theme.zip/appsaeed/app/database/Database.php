<?php

namespace App\database;

use Illuminate\Database\Capsule\Manager as Capsule;

class Database {

    /**
     * Insert table database
     */
    public static function seeder() {
        Seeder::planSeeder();
        Seeder::contentSeeder();
    }

    /**
     * @param bool $force force to create table schema
     * Create Table scheam
     */
    public static function createSchema( bool $force = false ) {

        TableSchema::planSchema( $force );
        TableSchema::imageSchema( $force );
        TableSchema::subscriptionSchema( $force );
        TableSchema::documentSchema( $force );
        TableSchema::appPasswordSchema( $force );
        TableSchema::purchaseLogSchema( $force );
        TableSchema::contentSchema( $force );

    }

    /**
     *  WP Database ojbect
     * @var \wpdb
     */
    public static function wp_db() {

        global $wpdb;
        return $wpdb;
    }

    /**
     * WP database table prefix
     * @return string
     */
    public static function prefix() {

        return self::wp_db()->prefix;
    }

    /**
     * WP database collate
     * @return string
     */
    public static function collate() {

        return self::wp_db()->collate;
    }

    /**
     * Create database connection with help of wordpress
     * @var \Illuminate\Database\Capsule\Manager $capsule
     */
    public static function createConnection(): Capsule {

        $capsule = new Capsule;
        $capsule->addConnection( [
            'driver' => 'mysql',
            'host' => DB_HOST,
            'database' => DB_NAME,
            'username' => DB_USER,
            'password' => DB_PASSWORD,
            'charset' => DB_CHARSET,
            'prefix' => self::prefix(), // Adjust for your WordPress table prefix
        ] );

        $capsule->setAsGlobal();
        $capsule->bootEloquent();

        return $capsule;
    }

}