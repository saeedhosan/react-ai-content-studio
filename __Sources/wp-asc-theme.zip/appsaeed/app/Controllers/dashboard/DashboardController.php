<?php
namespace App\controllers\dashboard;

class DashboardController
{

}
