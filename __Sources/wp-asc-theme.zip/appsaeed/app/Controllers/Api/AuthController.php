<?php

namespace App\Controllers\Api;

use App\config\Settings;
use App\helpers\Auth;
use App\helpers\Helpers;
use App\Models\Plans;
use App\Models\Subscriptions;
use App\Models\AppPassword;
use WP_REST_Request;


class AuthController extends Helpers
{
    /**
     * Register a new user
     *
     * @param  WP_REST_Request $request Full details about the request.
     * @return array $args.
     **/
    public function signup(WP_REST_Request $request)
    {

        try {
            //get all parameters as json
            $parameters = $request->get_json_params();

            $nickname = isset($parameters['nickname']) ? $parameters['nickname'] : '';
            $usermail = isset($parameters['usermail']) ? $parameters['usermail'] : '';
            $password = isset($parameters['password']) ? $parameters['password'] : '';

            // $username = sanitize_user($parameters['username']);
            $usermail = sanitize_email($usermail);
            $nickname = sanitize_text_field($nickname);
            // $role = sanitize_text_field( $parameters['role']);

            //required field
            if (empty($nickname)) {
                return  $this->error('The name field is required');
            }
            if (empty($usermail)) {
                return $this->error('The email field is required');
            }
            if (strlen($password) < 6) {
                return $this->error('password should be at least 6 characters');
            }

            if (!is_email($usermail)) {
                return  $this->error('The email address is not valid!');
            }

            // if (!validate_username($usermail) || in_array($usermail, ['admin'])) {
            //     return $this->error('The user name is invalid');
            // }

            //check if user exits or not {
            // if (username_exists($usermail)) {
            //     return   $this->error('Username already exists, please try another username');
            // }

            if (email_exists($usermail)) {

                return $this->error('The email already exists, please try Reset Password');
            } else {

                $user_id = wp_create_user($usermail, $password, $usermail);

                if (!is_wp_error($user_id)) {
                    // Get User Meta Data (Sensitive, Password included. DO NOT pass to front end.)
                    $user = get_user_by('id', $user_id);

                    // $user->set_role( $role );
                    $user->set_role('subscriber');

                    // WooCommerce specific code
                    if (class_exists('WooCommerce')) {
                        $user->set_role('customer');
                    }

                    $userdata = [
                        'ID' => $user->ID,
                        'user_pass' => $user->user_pass,
                        'user_login' => $user->user_login,
                        'user_nicename' => $nickname,
                        'user_url' => get_site_url(),
                        'user_email' => $usermail,
                        'display_name' => $nickname,
                        'nickname' => $nickname,
                        'first_name' => $nickname,
                        'last_name' => '',
                        'description' => 'new user',
                        'rich_editing' => true, // false - disable the visual editor
                        'role' => 'subscriber', // (string) user role
                    ];

                    wp_update_user($userdata);

                    wp_new_user_notification($user->ID, 'both');

                    wp_clear_auth_cookie();
                    wp_set_current_user($user->ID); // Set the current user detail
                    wp_set_auth_cookie($user->ID);

                    $plan = Plans::default();

                    Subscriptions::create([
                        'uid' => uniqid(time()),
                        'user_id' => $user->ID,
                        'plan_id' => $plan->id,
                        'words' => $plan->words(),
                        'image' => $plan->image(),
                        'start_at' => $plan->start_date(),
                        'end_at' => $plan->end_date(),
                        'status' => 'active',
                    ]);

                    $jwt_token = Auth::set($user->user_login, true);

                    $user_res = [
                        'user__id' => $user->data->ID,
                        'nickname' => $nickname,
                        'username' => $user->data->user_login,
                        'usermail' => $user->data->user_email,
                        'user_img' => get_avatar_url($user->ID),
                        'user_jwt' => $jwt_token
                    ];

                    return $this->response([
                        'success' => true,
                        'message' => 'Account was created successfull!',
                        'user'    => $user_res
                    ]);
                } else {
                    return $this->error('Somthing went wrong to create account! please try again!');
                }
            }
        } catch (\Throwable $th) {
            return  $this->error($th->getMessage(), 500);
        }
    }

    /**
     * wordpress method login
     *
     */

    public function login(WP_REST_Request $request)
    {

        $parms = $request->get_json_params();
        $username = isset($parms['username']) ? $parms['username'] : 'devsaeed';
        $password = isset($parms['password']) ? $parms['password'] : 'devsaeed';
        $remember = isset($parms['remember']) ? $parms['remember'] : false;

        $data = [
            'user_login' => $username,
            'user_password' => $password,
            'remember' => $remember,
        ];

        $user = wp_signon($data, false);

        if (is_wp_error($user)) {
            return $this->error($user->get_error_message(), 500);
        }

        $jwt_token = Auth::set($username, $remember);

        $data = [
            'user__id' => $user->data->ID,
            'nickname' => $user->data->display_name,
            'username' => $user->data->user_login,
            'usermail' => $user->data->user_email,
            'user_img' => get_avatar_url($user->ID),
            'user_jwt' => $jwt_token
        ];

        return $this->response([
            'success' => true,
            'message' => 'Logged in was successfull!',
            'user'    => $data
        ]);
    }

    public function logout()
    {
        Auth::unset();
        return $this->response([
            'success' => true,
            'message' => 'Auth session removed!'
        ]);
    }

    public function forgetPassword(WP_REST_Request $request)
    {
        try {

            $email = sanitize_text_field($request->get_param('username'));
            $home_url = sanitize_text_field($request->get_param('home_url'));

            if (empty($email)) {
                return $this->error('The email field is required');
            }
            if (!username_exists($email)) {
                return $this->error(__('Sorry! the given infromation doesn\'t exits in our system!'));
            }

            $user = get_user_by('email', $email);

            if (!username_exists($email)) {
                return $this->error(__('Sorry! We are unable to find information'));
            }
            $username = $user->data->user_login;

            $key = get_password_reset_key($user);
            $reset_url = "$home_url/password-reset?key=$key&username=$username";

            $message = "<h2>You have made a password rest request for the following account</h2><br><br>";
            $message .= "<b>Username</b>: $username <br>";
            $message .= "<b>Email</b>: $email <br><br>";
            $message .= "<b>Visite url</b>: $home_url <br><br>";

            $message .= "<h3>To reset your password, visit the following address:</h3>";
            $message .= '<a href="' . $reset_url . '" style="font-size:13px;font-weight:500;letter-spacing:.25px;text-decoration:none;text-transform:none;display:inline-block;border-radius:3px;padding:6px 20px;background-color:#1a73e8;color:#fff">Password Reset</a><br><br>';
            $message .= "if unable to open the avobe link open the link in browser address bar: <br> $reset_url";

            $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
            $title = sprintf(__('Password Reset - %s'), $blogname);
            $title = apply_filters('retrieve_password_title', $title);
            $message = apply_filters('retrieve_password_message', $message, $key);

            if ($message && !wp_mail($username, $title, $message, array('Content-Type: text/html; charset=\"utf-8\"\r\n')))
                return $this->error(__('The e-mail could not be sent.') . "<br />\n" . __('Possible reason: your host may have disabled the mail() function...'));

            return $this->response([
                'success'   => true,
                'message'      => "We have sent password rest link to the following please check your email address or try rest again!"
            ]);
        } catch (\Throwable $th) {
            return $this->error($th->getMessage());
        }
    }

    public function passwordReset(WP_REST_Request $request)
    {
        $username = sanitize_text_field($request->get_param('username'));
        $key = sanitize_text_field($request->get_param('key'));
        $password = $request->get_param('password');

        if (strlen($password) < 6) {
            return $this->error('password should be at least 6 characters');
        }

        $user = check_password_reset_key($key, $username);

        if (is_wp_error($user) && !$user->data) {
            return $this->error($user->get_error_message());
        } else {

            wp_set_password($password, $user->data->ID);

            return $this->response([
                'success' => true,
                'message' => 'password was update please use the password to login!'
            ]);
        }
    }




    public function user()
    {

        if (Auth::user()) {
            return $this->response([
                'success' => true,
                'message' => 'user is logged in',
                'user'    => Auth::user()
            ]);
        }

        return $this->success('auth session token expired!');
    }


    /**
     * wp get user if logged in
     */
    public function user_drop($request)
    {
        $data = 'not login';

        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            if ($user->data) {
                $data = [
                    'user__id' => $user->data->ID,
                    'nickname' => $user->data->display_name,
                    'username' => $user->data->user_login,
                    'usermail' => $user->data->user_email,
                    'user_img' => get_avatar_url($user->ID)
                ];
            }
        }

        return $data;
    }

    public function wp_logout()
    {
        add_action('wp_logout', 'auto_redirect_after_logout');

        function auto_redirect_after_logout()
        {
            wp_safe_redirect(home_url());
            exit;
        }
    }
}
