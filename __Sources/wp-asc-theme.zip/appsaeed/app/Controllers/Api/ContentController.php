<?php

namespace App\Controllers\Api;

use App\helpers\Auth;
use App\helpers\Helpers;
use App\Models\Content;

class ContentController extends Helpers {

    public function index() {

        $content = Content::where( 'key', 'home_sections' )->first();

        $data = [];

        $data['auth'] = Auth::user();

        if ( $content ) {
            $data['content'] = json_decode( $content->value );
        }

        return $this->response( $data );
    }
}
