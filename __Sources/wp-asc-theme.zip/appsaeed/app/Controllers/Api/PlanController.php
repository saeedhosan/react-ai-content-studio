<?php

namespace App\Controllers\Api;

use App\helpers\Helpers;
use App\Models\Plans;
use WP_REST_Response;

class PlanController extends Helpers {
    public function all(): WP_REST_Response {
        $data = Plans::all()->toArray();
        return $this->success( $data );
    }
}
