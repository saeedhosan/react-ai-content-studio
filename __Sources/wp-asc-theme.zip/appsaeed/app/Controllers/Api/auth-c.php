<?php

namespace App\Controllers\Api;

use App\config\Settings;
use App\helpers\Helpers;
use App\Models\Plans;
use App\Models\Subscriptions;
use App\Models\AppPassword;
use Mail;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;


class AuthController extends Helpers
{
    /**
     * Register a new user
     *
     * @param  WP_REST_Request $request Full details about the request.
     * @return array $args.
     **/
    public function signup(WP_REST_Request $request)
    {

        $origin =  $request->get_header('origin');

        try {
            //get frontend request url


            //get all parameters as json
            $parameters = $request->get_json_params();

            $nickname = isset($parameters['nickname']) ? $parameters['nickname'] : '';
            $usermail = isset($parameters['usermail']) ? $parameters['usermail'] : '';
            $password = isset($parameters['password']) ? $parameters['password'] : '';

            // $username = sanitize_user($parameters['username']);
            $usermail = sanitize_email($usermail);
            $nickname = sanitize_text_field($nickname);
            // $role = sanitize_text_field( $parameters['role']);

            //required field
            if (empty($nickname)) {
                return  $this->error('The name field is required');
            }
            if (empty($usermail)) {
                return $this->error('The email field is required');
            }
            if (empty($password)) {
                return $this->error('password should be at least 6 characters');
            }

            if (!is_email($usermail)) {
                return  $this->error('The email address is not valid!');
            }

            // if (!validate_username($usermail) || in_array($usermail, ['admin'])) {
            //     return $this->error('The user name is invalid');
            // }

            //check if user exits or not {
            // if (username_exists($usermail)) {
            //     return   $this->error('Username already exists, please try another username');
            // }

            if (email_exists($usermail)) {

                return $this->error('The email already exists, please try Reset Password');
            } else {

                $user_id = wp_create_user($usermail, $password, $usermail);

                if (!is_wp_error($user_id)) {
                    // Get User Meta Data (Sensitive, Password included. DO NOT pass to front end.)
                    $user = get_user_by('id', $user_id);

                    // $user->set_role( $role );
                    $user->set_role('subscriber');

                    // WooCommerce specific code
                    if (class_exists('WooCommerce')) {
                        $user->set_role('customer');
                    }

                    //php mailer variables
                    // wp_mail(
                    //     $to,
                    //     "New User Signup for " + Settings::get('app_name'),
                    //     "You have new user from  username: $usermail",
                    //     array('Content-Type: text/plain; charset=\"utf-8\"\r\n')
                    // );

                    // wp_mail(
                    //     $user->user_email,
                    //     "Signup successfully at by $usermail",
                    //     "Your username: $usermail ",
                    //     array('Content-Type: text/plain; charset=\"utf-8\"\r\n')
                    // );

                    $userdata = [
                        'ID' => $user->ID,
                        'user_pass' => $user->user_pass,
                        'user_login' => $user->user_login,
                        'user_nicename' => $usermail,
                        'user_url' => get_site_url(),
                        'user_email' => $user->user_email,
                        'display_name' => $user->display_name,
                        'nickname' => 'nkname',
                        'first_name' => $nickname,
                        'last_name' => '',
                        'description' => 'new user',
                        'rich_editing' => true, // false - disable the visual editor
                        'role' => 'subscriber', // (string) user role
                    ];

                    wp_update_user($userdata);
                    wp_new_user_notification($user->ID, 'both');

                    wp_clear_auth_cookie();
                    wp_set_current_user($user->ID); // Set the current user detail
                    wp_set_auth_cookie($user->ID);

                    $plan = Plans::default();

                    Subscriptions::create([
                        'uid' => uniqid(time()),
                        'user_id' => $user->ID,
                        'plan_id' => $plan->id,
                        'words' => $plan->words(),
                        'image' => $plan->image(),
                        'start_at' => $plan->start_date(),
                        'end_at' => $plan->end_date(),
                        'status' => 'active',
                    ]);

                    return $this->success('Account was successfully created');
                } else {
                    return $this->error('Somthing went wrong to create account! please try again!');
                }
            }
        } catch (\Throwable $th) {
            return  $this->error($th->getMessage(), 500);
        }
    }

    public function login(WP_REST_Request $request)
    {

        if (isset($_COOKIE[Settings::get('auth_cookie_name')])) {
            return $this->response([
                'success' => true,
                'message' => 'User already logged!',
                'token'   => $_COOKIE[Settings::get('auth_cookie_name')],
            ]);
        }

        $parms = $request->get_json_params();
        $username = isset($parms['username']) ? $parms['username'] : 'devsaeed';
        $password = isset($parms['password']) ? $parms['password'] : 'devsaeed';
        $remember = isset($parms['remember']) ? $parms['remember'] : true;

        $user = wp_signon([
            'user_login' => $username,
            'user_password' => $password,
            'remember' => $remember,
        ], false);

        if (is_wp_error($user)) {
            return $this->error($user->get_error_message(), 500);
        }

        $app_pass_data = AppPassword::where('username', $username)->first();

        if (!$app_pass_data && !$app_pass_data->password) {
            $app_pass_data = $this->create_app_pass($user->data->ID, $username);
        }

        $app_pass = $app_pass_data->password;

        wp_clear_auth_cookie();
        wp_set_current_user($user->ID); // Set the current user detail
        wp_set_auth_cookie($user->ID); // Set auth details in cookie

        $cookie_name = Settings::get('auth_cookie_name');
        $cookie_value = base64_encode("$username:$app_pass");
        $cookie_expire =  time() + (60 * 60);
        $origin_domain = parse_url($request->get_header('origin'));
        setcookie($cookie_name, $cookie_value,  $cookie_expire, '/', 'localhost', false, true);


        $data = [
            'user__id' => $user->data->ID,
            'nickname' => $user->data->display_name,
            'username' => $user->data->user_login,
            'usermail' => $user->data->user_email,
            'user_img' => get_avatar_url($user->ID)
        ];

        return $this->response([
            'success' => true,
            'message' => 'Logged in was successfull!',
            'token'   => $cookie_value,
            'user'    => $data
        ]);
    }

    /**
     * wordpress method login
     *
     */
    public function login_web($request = null)
    {
        $parms = $request->get_json_params();
        $username = isset($parms['username']) ? $parms['username'] : '';
        $password = isset($parms['password']) ? $parms['password'] : '';
        $remember = isset($parms['remember']) ? $parms['remember'] : false;

        $data = [
            'user_login' => $username,
            'user_password' => $password,
            'remember' => $remember,
        ];

        $user = wp_signon($data, false);

        if (is_wp_error($user)) {
            return $this->error($user->get_error_message(), 500);
        } else {

            wp_clear_auth_cookie();
            wp_set_current_user($user->ID); // Set the current user detail
            wp_set_auth_cookie($user->ID); // Set auth details in cookie

            return $this->success([
                'success' => true,
                'message' => 'Logged in successfully',
                'data' => $user,
            ]);
        }
    }
    /**
     * wp logout api
     */
    public function wp_logout()
    {
        add_action('wp_logout', 'auto_redirect_after_logout');

        function auto_redirect_after_logout()
        {
            wp_safe_redirect(home_url());
            exit;
        }
    }

    /**
     * wp get user if logged in
     */
    public function user($request)
    {
        $data = null;

        if (isset($_COOKIE[Settings::get('auth_cookie_name')])) {
            $cookie = $_COOKIE[Settings::get('auth_cookie_name')];
            $base64 = explode(':', base64_decode($cookie));
            $username = isset($base64[0]) ? $base64[0] : '';
            $user     = _wp_get_current_user();
            return $user;
        }

        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            if ($user->data) {
                $data = [
                    'user__id' => $user->data->ID,
                    'nickname' => $user->data->display_name,
                    'username' => $user->data->user_login,
                    'usermail' => $user->data->user_email,
                    'user_img' => get_avatar_url($user->ID)
                ];
            }
        }

        return $data;
    }


    public function create_app_pass($user_id, $username)
    {
        // Set the API endpoint URL
        $url = get_site_url() . "/wp-json/wp/v2/users/$user_id/application-passwords";


        // Send the POST request to generate the app password
        $response = wp_remote_post($url, array(
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization'     => Settings::get('authorization')
            ],
            'body'    => wp_json_encode([
                'name' => 'My App' . uniqid(),
                'description' => 'Description of my app'
            ])
        ));

        $code       = wp_remote_retrieve_response_code($response);
        $message    = wp_remote_retrieve_response_message($response);
        $body       = json_decode(wp_remote_retrieve_body($response), true);
        $code       = intval($code);

        // Parse the response and retrieve the app password
        if (!is_wp_error($response) && isset($body['password'])) {
            $app_pass = $body['password'];
            $data =  AppPassword::create([
                'user_id'   => $user_id,
                'username' => $username,
                'password' => $app_pass,
                'options'  => json_encode($body)
            ]);
            return $data;
        }

        return $this->response($body, $code);
    }
}




/**
 * Handles sending password retrieval email to user.
 *
 * @uses $wpdb WordPress Database object
 * @param string $user_login User Login or Email
 * @return bool true on success false on error
 */
function retrieve_password($user_login, $key)
{

    $message = __('Someone requested that the password be reset for the following account:') . "\r\n\r\n";
    $message .= network_home_url('/') . "\r\n\r\n";
    $message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
    $message .= __('If this was a mistake, just ignore this email and nothing will happen.') . "\r\n\r\n";
    $message .= __('To reset your password, visit the following address:') . "\r\n\r\n";
    $message .= '<' . network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') . ">\r\n";

    $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);

    $title = sprintf(__('[%s] Password Reset'), $blogname);

    $title = apply_filters('retrieve_password_title', $title);
    $message = apply_filters('retrieve_password_message', $message, $key);

    if ($message && !wp_mail($user_login, $title, $message))
        wp_die(__('The e-mail could not be sent.') . "<br />\n" . __('Possible reason: your host may have disabled the mail() function...'));

    return true;
}
