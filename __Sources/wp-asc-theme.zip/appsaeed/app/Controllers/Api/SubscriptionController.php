<?php

namespace App\Controllers\Api;

use App\helpers\Helpers;
use App\Models\Subscriptions;

class SubscriptionController extends Helpers
{
    /**
     * get subscription status for current user
     */
    public function activeSubscription()
    {
        $subscription = null;
        if (Subscriptions::activeSubscription()) {
            $subscription = Subscriptions::activeSubscription();
            $subscription->plan = Subscriptions::activeSubscription()->plan;
        }
        return $this->response($subscription);
    }


    public function cancel($request = null)
    {
        try {
            // $parms = $request->get_json_params();
            // $subscription_id = isset($parms['id']) ? $parms['id'] : 0;



            //check is subscrption has
            if (!$this->subscribe()) {
                return $this->subscribe();
            }

            if (Subscriptions::cancel()) {
                $this->success('Subscription canceled');
            }

            return $this->error('Something went worng please try again later');
        } catch (\Throwable $th) {
            return $this->error($th->getMessage());
        }
    }
}
