<?php

namespace App\Controllers\Api;

use App\helpers\Auth;
use App\helpers\Helpers;
use App\Models\Images;
use App\Models\Subscriptions;
use App\Models\User;

class ImageController extends Helpers
{

    /**
     * get all  generated images
     */
    public function index()
    {

        $images = Images::where('user_id', Auth::id())->orderBy('id', 'DESC')->get();
        return $this->response($images);
    }

    /**
     * create image with open ai
     */
    public function create($request = null)
    {

        try {

            if ($this->subscribe()) {
                return $this->subscribe();
            }

            if ($this->canGenererateImage()) {
                return $this->canGenererateImage();
            }

            $parms = $request->get_json_params();
            $size = isset($parms['size']) ? $parms['size'] : '256x256';
            $prompt = isset($parms['prompt']) ? $parms['prompt'] : 'any';
            $title = isset($parms['title']) ? $parms['title'] : '';

            // $response = $this->openai('/images/generations', [
            //     "prompt" => $prompt,
            //     "n" => 1,
            //     "size" => $size,
            //     "response_format" => "b64_json",
            // ]);

            // $base64_string = $response->data[0]->b64_json;
            // $image_url     = $this->upload_base64_image($base64_string, $prompt);
            $new__size = str_replace('x', '/', $size);
            $image_url = "https://picsum.photos/$new__size?random=1";

            $url = $this->wp_upload_from_url($image_url);


            Images::create([
                'uid'               => uniqid(),
                'user_id'           => Auth::id(),
                'subscription_id'   => Subscriptions::activeSubscription()->id,
                'url'               => $url,
                // 'path'              => $base64_string,
                'path'              => '',
                'size'              => $size,
                'name'              => $prompt,
                'title'             => $title,
                // 'data'              => $response
            ]);

            Subscriptions::activeSubscription()->decressdImage();

            return $this->success('Image successfully generated!');

            //done
        } catch (\Throwable $th) {
            return  $this->error($th->getMessage(), 500);
        }
    }
    /**
     * delete generated image by id
     */
    public function delete($request = null)
    {
        try {
            $id = $request->get_param('id');

            if (empty($id)) {
                return $this->error(__('Sorry! not able to delete id missing'));
            }

            if (Images::where('id', $id)->count()  < 1) {
                return $this->error('Sorry: image was not found');
            }

            Images::where('id', $id)->delete();

            return $this->success('image deleted successfull');
        } catch (\Throwable $th) {
            return $this->response($th->getMessage());
        }
    }
}
