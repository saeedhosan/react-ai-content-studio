<?php

namespace App\Controllers\Api;

use App\helpers\Auth;
use App\helpers\Helpers;
use App\Models\Comments;
use App\Models\Subscriptions;
use App\Models\User;


class SupportController extends Helpers
{

    public function index()
    {
        try {
            $user_id = Auth::id();
            $data    = null;
            $supports =  Comments::where(
                [
                    'user_id' => $user_id,
                    'comment_type' => 'support',
                ]
            )
                ->where('comment_approved', '!=', 'trash')
                ->get();

            foreach ($supports as $support) {

                $comments = get_comments([
                    'parent' => $support->comment_ID,
                    'orderby'  => 'ASC',
                    'order'  => 'ASC',
                ]);;
                $support->children = $comments;
                $data[] = $support;
            }


            return $this->response($data);
        } catch (\Throwable $th) {
            return $this->response($th->getMessage(), 500);
        }
    }

    /**
     * create support trket
     * 
     */
    public function create($request)
    {

        try {
            $parms = $request->get_params();
            $attache = '';

            if ($this->has_file('attache')) {
                $mimes = [
                    'txt', 'csv', 'doc', 'jpg', 'jpeg', 'gif', 'png', 'mp4', 'json', 'zip', 'pdf',
                ];

                if (!$this->allow_mimes('attache', $mimes)) {
                    return  $this->error(__('We are not allowed The File! '));
                }

                $attache = $this->wp_upload_ajax('attache');
            }

            $page = get_page_by_path('dashboard_support');
            $page_id = $page->ID ? $page->ID : 0;
            $user_name = Auth::user()->nickname ?? 'unknown';
            $user_email = Auth::user()->usermail ?? 'unknown';
            //get request
            $subject    = isset($parms['subject']) ? $parms['subject'] : 'no subject';
            $message    = isset($parms['message']) ? $parms['message'] : 'no message';

            $content    = "";
            if ($attache) {
                $content    .= "<br/><b>Attachment</b>: <a target='_blank' href='$attache' alt='file'>See attachment</a><br/><br>";
            }
            $content .= "<div class='support-message'>$message</div>";

            $data = array(
                'user_id'   => Auth::id(),
                'comment_author' => 'Support Request by: ' . $user_name,
                'comment_author_email' => $user_email,
                'comment_author_url' => uniqid(),
                'comment_author_IP' => $subject,
                'comment_content' => $content,
                'comment_post_ID' =>  $page_id,
                'comment_agent' => $_SERVER['HTTP_USER_AGENT'],
                'comment_type' => 'support',
                'comment_date' => date('Y-m-d H:i:s'),
                'comment_date_gmt' => date('Y-m-d H:i:s'),
                'comment_approved' => 0,
            );

            wp_insert_comment($data);

            return $this->success('Support was mede request please whole wait for resposne our team will contact soon!');
        } catch (\Throwable $th) {
            return $this->error("Server error: " . $th->getMessage());
        }
    }


    /**
     * wp reply comment 
     * 
     */
    public function reply($request = null)
    {

        try {
            $parms = $request->get_json_params();

            if (!isset($parms['username'])) {
                return $this->error(__('The username field is required'));
            } elseif (!isset($parms['message'])) {
                return $this->error(__('The message field is required'));
            } elseif (!isset($parms['comment_id'])) {
                return  $this->error(__('The support id is required!'));
            }

            $email =  $parms['email'];
            $username =  $parms['username'];
            $email =  isset($parms['email']) ? $parms['email'] : '';
            $message =  $parms['message'];
            $comment_id = $parms['comment_id'];

            $data = array(
                'user_id'   => 10,
                'comment_parent' =>  $comment_id,
                'comment_author' =>  $username,
                'comment_author_email' => $email,
                'comment_author_url' => '',
                'comment_content' => $message,
                'comment_agent' => $_SERVER['HTTP_USER_AGENT'],
                'comment_type' => 'comment',
                'comment_date' => date('Y-m-d H:i:s'),
                'comment_date_gmt' => date('Y-m-d H:i:s'),
                'comment_approved' => 0,
            );

            wp_insert_comment($data);

            return  $this->success('Message successfully replied!');
        } catch (\Throwable $th) {
            return  $this->error($th->getMessage());
        }
    }
}
