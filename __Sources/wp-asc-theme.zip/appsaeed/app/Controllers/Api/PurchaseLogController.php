<?php

namespace App\Controllers\Api;

use App\helpers\Auth;
use App\helpers\Helpers;
use App\Models\PurchaseLog;
use App\Models\Subscriptions;
use App\Models\User;

class PurchaseLogController extends Helpers
{

    /**
     * get all purchase history for loggin user 
     */
    public function index($request = null)
    {

        $logs = PurchaseLog::where('user_id', Auth::id())->orderBy('id', 'desc')->get();

        return $this->response($logs);
    }
}
