<?php

namespace App\Controllers\Api;

use App\helpers\Helpers;
use App\Models\User;
use WP_REST_Request;
use WP_REST_Response;

class PostController extends Helpers
{

    public function posts(): WP_REST_Response
    {
        $data = [];

        $per_page = ASC_POST_PER_PAGE;

        $url  = get_site_url() . '/wp-json/wp/v2/posts?per_page=' . $per_page;

        $request = wp_remote_get($url);
        if (is_wp_error($request)) {
            $data = null;
        } else {
            $body = wp_remote_retrieve_body($request);
            $posts = json_decode($body);
            foreach ($posts as $post) {
                $data[] = [
                    'id'            => $post->id,
                    'date'          => $post->date,
                    'slug'          => $post->slug,
                    'status'        => $post->status,
                    'link'          => $post->link,
                    'title'         => $post->title->rendered,
                    'image'         => wp_get_attachment_url($post->featured_media),
                    'author'        => get_user_by("id", $post->author)->data->display_name,
                    'content'       => $post->content->rendered

                ];
            }
        }

        return $this->success($data);
    }


    public function post(WP_REST_Request $request): WP_REST_Response
    {
        $data = [];
        $slug   = $request->get_param('slug');

        $url  = get_site_url() . '/wp-json/wp/v2/posts/?slug=' . $slug;

        $request = wp_remote_get($url);
        if (is_wp_error($request)) {
            $data = null;
        } else {
            $body = wp_remote_retrieve_body($request);
            $posts = json_decode($body);

            if (count($posts) > 0) {
                foreach ($posts as $post) {
                    $data = [
                        'id'            => $post->id,
                        'date'          => $post->date,
                        'slug'          => $post->slug,
                        'status'        => $post->status,
                        'link'          => $post->link,
                        'title'         => $post->title->rendered,
                        'image'         => wp_get_attachment_url($post->featured_media),
                        'author'        => get_user_by("id", $post->author)->data->display_name,
                        'content'       => $post->content->rendered

                    ];
                }
            } else {
                $data = null;
            }
        }

        return $this->success($data);
    }
}
