<?php
namespace App\Controllers;

class GeneralController {

    public function favicon() {

        $favicon_path = get_site_icon_url();

        // Check if a favicon exists
        if ( $favicon_path ) {
            // Get the file extension
            $extension = pathinfo( $favicon_path, PATHINFO_EXTENSION );

            // Set the appropriate content type based on the file extension
            switch ( $extension ) {
            case 'png':
                $content_type = 'image/png';
                break;
            case 'ico':
                $content_type = 'image/x-icon';
                break;
            default:
                $content_type = 'image/png'; // Set a default content type if the extension is not recognized
                break;
            }

            // Output the image with the appropriate content type
            header( 'Content-Type: ' . $content_type );
            readfile( $favicon_path );
            // exit();
        } else {
            // Fallback response if no favicon is set
            return rest_ensure_response( ['error' => 'No favicon found'] );
        }
    }

}