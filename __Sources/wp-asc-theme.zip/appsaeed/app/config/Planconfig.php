<?php

namespace App\config;

class Planconfig
{
    /**
     * set  as true if want to update always when update plan done 
     * please stop auto update by set false for parformance
     * @param bool $autoload
     * @return bool
     */
    public static $autoload = false;

    /**
     * This can be update for customize plans 
     * @return array plans
     */
    public static function plans()
    {
        return [
            [
                "name"          => 'professional',
                "slug"          => 'professional',
                "words"         => 30000,
                "image"         => 30,
                "description"   => 'this is an professional plan',
                "price"         => '9.97',
                "billing_cycle" => 'monthly',
                "frequency_unit" => 1,
                "items"         => json_encode([
                    '30, 000 words',
                    '30 images',
                    'All templates',
                    'Unlimited access',
                    'Full time support'
                ]),
                "is_default" => true,
                "is_popular" => false,
            ],
            [
                "name"          => 'Team',
                "slug"          => 'team',
                "words"         => 300000,
                "image"         => 100,
                "description"   => 'this is an team plan',
                "price"         => '19.97',
                "billing_cycle" => 'monthly',
                "frequency_unit" => 1,
                "items"         => json_encode([
                    '300, 000 words',
                    '100 images',
                    'All templates',
                    'Unlimited access',
                    'Full time support'
                ]),
                "is_default" => false,
                "is_popular" => true,
            ],
            [
                "name"          => 'Business',
                "slug"          => 'business',
                "words"         => 600000,
                "image"         => 200,
                "description"   => 'this is an business plan',
                "price"         => '39.97',
                "billing_cycle" => 'monthly',
                "frequency_unit" => 1,
                "items"         => json_encode([
                    '600, 000 words',
                    '200 images',
                    'All templates',
                    'Unlimited access',
                    'Full time support'
                ]),
                "is_default" => false,
                "is_popular" => true,
            ],

        ];
    }
}
