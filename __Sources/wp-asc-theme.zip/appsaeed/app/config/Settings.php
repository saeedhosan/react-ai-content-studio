<?php

namespace App\config;

class Settings {
    /**
     * making config settings for react frontend
     */
    public static function all() {
        return [
            'app_url' => get_site_url(),
            'app_name' => 'Appsaeed',
            'app_title' => get_bloginfo(),
            'app_address' => "Dhaka, Bangladesh",
            'app_icon' => get_site_icon_url(),
            'app_nonce' => wp_create_nonce( 'wp_rest' ),
            'wp_rest_url' => get_rest_url() . 'wp/v2/',
            'app_rest_url' => get_rest_url() . ASC_REST_PATH,
            'app_currency' => 'USD',
            'frontend_path' => 'http://localhost:3000',
            /**
             *
             */
            'authorization' => 'Basic YXBwc2FlZWQ6ZWpNOCBjMTFoIEE4bG8gSnE1UCB5YzFLIGZDVVA=',

            /**
             * stripe public key
             */
            'app_stripe_key' => 'pk_test_51MqZQWIlkqN6DZkb1PYJeXo7MFJzin33XtY98CGLRbIxCMULTuKVJwUrcuJOBclEf9JvQ0NZzlrLDMtWP5971bjk00PJRLcvgb',

            /**
             * stripe screet key
             */
            'stripe_screet' => 'sk_test_51MqZQWIlkqN6DZkbE7E7BaP6XVzBxMujlrgp2mizjj32DGwxG0xjhX5k3rU9KhdtD4VjwSLgSjqxEdPwohKtipE200yEy9LziG',
            /**
             * stripe screet key
             */
            'openai_key' => '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',
        ];
    }

    /**
     * You should not touch under this methods
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     * ========================================
     */

    /**
     * get settting
     */
    public static function get( $name = null ): string {
        return isset( self::all()[$name] ) ? self::all()[$name] : '';
    }
}
