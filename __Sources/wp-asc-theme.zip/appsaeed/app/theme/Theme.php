<?php

namespace App\theme;

use App\routes\API;

class Theme {

    /**
     * map api routes
     */
    public static function api() {
        API::map();
    }

    /**
     * setup theme
     */
    public static function setup() {
        self::createPage();
        // self::api_post_field();
        self::menus();
        self::after_setup_theme();
    }

    /**
     * create init page required
     */
    public static function createPage() {
        $pages = ['login', 'signup', 'dashboard_support'];

        foreach ( $pages as $page ) {
            $check_page = get_page_by_path( $page );
            if ( empty( $check_page ) ) {
                wp_insert_post(
                    [
                        'comment_status' => 'close',
                        'ping_status' => 'close',
                        'post_author' => 1,
                        'post_title' => $page, //ucwords($page)
                        'post_name' => strtolower( str_replace( ' ', '-', trim( $page ) ) ),
                        'post_status' => 'publish',
                        'post_content' => $page,
                        'post_type' => 'page',
                        'post_parent' => 'id_of_the_parent_page_if_it_available',
                    ]
                );
            }
        }
    }

    /**
     * create api rest field
     */
    public static function api_post_field() {
        add_action( 'rest_api_init', function () {
            register_rest_field(
                'regions',
                'group',
                [
                    'get_callback' => 'get_post_meta_for_api',
                    'schema' => null,
                ]
            );
        } );
    }

    /**
     * add/support menu
     */
    public static function menus() {
        add_action( 'init', function () {
            register_nav_menus(
                [
                    'primary-menu' => __( 'Header Menu' ),
                    'secondary-menu' => __( 'Footer Menu' ),
                ]
            );
        } );
    }

    /**
     * wp support theme post meta
     */
    public static function after_setup_theme() {
        add_action( 'after_setup_theme', function () {
            add_theme_support( 'title-tag' );
            add_theme_support( 'post-thumbnails' );
        } );
    }

}
