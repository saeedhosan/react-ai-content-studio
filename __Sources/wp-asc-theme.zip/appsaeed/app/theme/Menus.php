<?php
namespace App\theme;

class Menus {

    public function hel() {
        $name = isset( $options['name'] ) ? $options['name'] : 'menu name';
        $slug = isset( $options['slug'] ) ? $options['slug'] : 'menu slug';
        $path = isset( $options['path'] ) ? $options['path'] : 'menu-path';
        $icon = isset( $options['icon'] ) ? $options['icon'] : get_template_directory_uri() . '/assets/images/menu-icon.svg';
        $title = isset( $options['title'] ) ? $options['title'] : $name;
        $manage = isset( $options['manage'] ) ? $options['manage'] : 'manage_options';
        $position = isset( $options['position'] ) ? $options['position'] : '';
    }

    public static function create( array $options = [], $callback = null ) {

        add_action( 'admin_menu', function () use ( $options, $callback ) {

            $options['name'] = isset( $options['name'] ) ? $options['name'] : 'menu name';
            $options['slug'] = isset( $options['slug'] ) ? $options['slug'] : 'menu slug';
            $options['path'] = isset( $options['path'] ) ? $options['path'] : 'menu-path';
            $options['icon'] = isset( $options['icon'] ) ? $options['icon'] : get_template_directory_uri() . '/assets/images/menu-icon.svg';
            $options['manage'] = isset( $options['manage'] ) ? $options['manage'] : 'manage_options';
            $options['position'] = isset( $options['position'] ) ? $options['position'] : null;

            add_menu_page(
                $options['name'],
                $options['name'],
                $options['manage'],
                $options['slug'],
                $callback,
                $options['icon'],
                $options['position']
            );
        } );
    }
}