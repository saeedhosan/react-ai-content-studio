<?php

namespace App\Models;

use App\helpers\Auth;
use Illuminate\Database\Eloquent\Model;

class User extends Model {
    /**
     * Name for table without prefix
     * @var string
     */
    protected $table = 'users';

    /**
     * Get table name with prefix
     */
    public function getPrefixedTable() {

        $tableName = $this->getTable();

        // Get the table prefix for the specified connection
        global $wpdb;
        $prefix = $wpdb->prefix;

        // Concatenate the prefix with the table name
        return $prefix . $tableName;
    }

    /**
     * check if user login
     */
    public static function isLogin() {
        if ( Auth::isLogin() ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * get user is login
     */
    public static function get() {
        if ( self::isLogin() ) {
            return Auth::user();
        } else {
            return false;
        }
    }
}
