<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comments extends Model {
    protected $table = ASC_TABLE_PREFIX . 'comments';

    /**
     * Columns that can be edited - IE not primary key or timestamps if being used
     */
    protected $fillable = [
        'uid',
        'comment_post_ID',
        'comment_author',
        'comment_author_email',
        'comment_author_url',
        'comment_date',
        'comment_date_gmt',
        'comment_content',
        'comment_karma',
        'comment_approved',
        'comment_agent',
        'comment_type',
        'comment_parent',
        'user_id',
    ];

    /** Everything below this is best done in an abstract class that custom tables extend */

    /**
     * Set primary key as ID, because WordPress
     *
     * @var string
     */
    protected $primaryKey = 'comment_ID';

    /**
     * Get table name with prefix
     */
    public function getPrefixedTable() {

        $tableName = $this->getTable();

        // Get the table prefix for the specified connection
        global $wpdb;
        $prefix = $wpdb->prefix;

        // Concatenate the prefix with the table name
        return $prefix . $tableName;
    }

    /**
     * get user
     */
    public function user() {
        return $this->belongsTo( User::class );
    }
}
