<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Images extends Model {

    /**
     * Name for table without prefix
     * @var string
     */
    protected $table = ASC_TABLE_PREFIX . 'images';

    /**
     * Columns that can be edited - IE not primary key or timestamps if being used
     */
    protected $fillable = [
        'uid',
        'user_id',
        'subscription_id',
        'url',
        'path',
        'name',
        'type',
        'size',
        'title',
        'resolution',
        'options',
        'data',
        'description',
    ];

    /** Everything below this is best done in an abstract class that custom tables extend */

    /**
     * Set primary key as ID, because WordPress
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * Find item by uid.
     *
     * @param $uid
     *
     * @return object
     */
    public static function findByUid( $uid ): object {
        return self::where( 'uid', $uid )->first();
    }

    /**
     * get route key by uid
     *
     * @return string
     */
    public function getRouteKeyName(): string {
        return 'uid';
    }

    /**
     * Bootstrap any application services.
     */
    public static function boot() {
        parent::boot();

        // Create uid when creating list.
        static::creating( function ( $item ) {
            // Create new uid
            $uid = uniqid();
            while ( self::where( 'uid', $uid )->count() > 0 ) {
                $uid = uniqid();
            }
            $item->uid = $uid;
        } );
    }

    /**
     * get user
     *
     * @return \App\Models\User
     */
    public function user(): BelongsTo {
        return $this->belongsTo( User::class );
    }

    /**
     * Get table name with prefix
     */
    public function getPrefixedTable() {

        $tableName = $this->getTable();

        // Get the table prefix for the specified connection
        global $wpdb;
        $prefix = $wpdb->prefix;

        // Concatenate the prefix with the table name
        return $prefix . $tableName;
    }
}
