<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppPassword extends Model {

    /**
     * Name for table without prefix
     * @var string
     */
    protected $table = ASC_TABLE_PREFIX . 'app_passwords';

    /**
     * Columns that can be edited - IE not primary key or timestamps if being used
     */
    protected $fillable = [
        'uid',
        'user_id',
        'username',
        'password',
        'pass_uid',
        'options',
    ];

    /** Everything below this is best done in an abstract class that custom tables extend */

    /**
     * Set primary key as ID, because WordPress
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * Get table name with prefix
     */
    public function getPrefixedTable() {

        $tableName = $this->getTable();

        // Get the table prefix for the specified connection
        global $wpdb;
        $prefix = $wpdb->prefix;

        // Concatenate the prefix with the table name
        return $prefix . $tableName;
    }

    /**
     * get user
     */
    public function user() {
        return $this->belongsTo( User::class );
    }
}
